package com.tw.progs.HandyEnglish;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class HandyEnglishApplication {

	public static void main(String[] args) {
		SpringApplication.run(HandyEnglishApplication.class, args);
	}
}
